export default class FsmEvent {
   
}
