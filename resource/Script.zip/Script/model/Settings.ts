export default class Settings{
    showSoftShadow = false;
    showGamepad = true;
    showEquipDialog = false;
    lowPower = false;
}